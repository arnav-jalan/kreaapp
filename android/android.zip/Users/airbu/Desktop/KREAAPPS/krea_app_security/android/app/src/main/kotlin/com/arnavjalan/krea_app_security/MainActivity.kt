package com.arnavjalan.krea_app_security

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
